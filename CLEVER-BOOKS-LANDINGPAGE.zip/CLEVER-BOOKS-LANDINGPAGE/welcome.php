<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $firstName = $_POST["firstName"];
    $lastName = $_POST["lastName"];
    $phoneNumber = $_POST["phoneNumber"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    
    // Perform any necessary validations or processing here
    
    // Redirect to welcome page with query parameters
    header("Location: welcome.html?firstName=" . urlencode($firstName) . "&email=" . urlencode($email));
    exit();
} else {
    // Redirect back to the signup form if accessed directly
    header("Location: signup.html");
    exit();
}
?>
